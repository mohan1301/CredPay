variable "name_prefix" {
  type = string
}

variable "location" {
  type = string
}

variable "resource_group_name" {
  type = string
}

variable "tags" {
    type = map(string)
}

variable "log_rentention_days"{
    type = number
}

